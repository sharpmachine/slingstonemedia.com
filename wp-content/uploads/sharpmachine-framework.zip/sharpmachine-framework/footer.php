
</div><!--end container>-->
<?php wp_footer(); ?>
<script src="http://ajax.googleapis.com/ajax/libs/jquery/1/jquery.min.js"></script>
<script src="<?php bloginfo('template_directory'); ?>/js/hashgrid.js" type="text/javascript"></script>
</body>
</html>
