<?php get_header(); ?>
<h1>This is a test</h1>
<?php get_footer(); ?>