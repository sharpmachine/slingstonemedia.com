<h5><?php _e('Using Advanced Customer Search','Shopp'); ?></h5>
<table border="0" class="advsearch">
	<tr><td><strong><?php _e('Email','Shopp'); ?>:</strong></td><td>help.desk@shopplugin.net</td></tr>
<tr><td><strong><?php _e('Company','Shopp'); ?>:</strong></td><td>company:"Ingenesis Limited"<br />company:automattic</td></tr>
<tr><td><strong><?php _e('Login','Shopp'); ?>:</strong></td><td>login:admin</td></tr>
<tr><td><strong><?php _e('Address (lines 1 or 2)','Shopp'); ?>:</strong></td><td>address:"1 main st"</td></tr>
<tr><td><strong><?php _e('City','Shopp'); ?>:</strong></td><td>city:"san jose"<br />city:columbus</td></tr>
<tr><td><strong><?php _e('State/Province','Shopp'); ?>:</strong></td><td>state:"new york"<br />province:ontario</td></tr>
<tr><td><strong><?php _e('Zip/Postal Codes','Shopp'); ?>:</strong></td><td>zip:95131<br />postcode:M1P1C0</td></tr>
<tr><td><strong><?php _e('Country','Shopp'); ?>:</strong></td><td>country:US</td></tr>
</table>
